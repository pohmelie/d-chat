"""
graphic file formats, including imagery (bmp, jpg, gif, png, ...),
models (3ds, ...), etc.
"""
